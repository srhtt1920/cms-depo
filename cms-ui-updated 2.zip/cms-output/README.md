# CMS UI — Bileşen Güncellemeleri

## Yeni / Güncellenen Dosyalar

```
Shared/Components/Table/
    DataTable.razor        ← Ortak tablo bileşeni (YENİ)
    Paginator.razor        ← Sayfalama bileşeni (YENİ)
    ExportButton.razor     ← Bağımsız export bileşeni (YENİ)

wwwroot/js/
    cms-table-helpers.js   ← JS interop (cmsDownloadText) (YENİ)

wwwroot/css/
    cms-table.css          ← Tablo stilleri (YENİ)

Pages/Contents/Contents.razor   ← Güncellendi
Pages/Roles/Roles.razor         ← Güncellendi
Pages/Users/Users.razor         ← Güncellendi
```

---

## Kurulum Adımları

### 1. JS dosyasını ekle

`wwwroot/js/cms-table-helpers.js` dosyasını projeye kopyalayın,
ardından `_Host.cshtml` (Blazor Server) veya `index.html` (WASM) içine:

```html
<script src="js/cms-table-helpers.js"></script>
```

### 2. CSS dosyasını ekle

`wwwroot/css/cms-table.css` dosyasını projeye kopyalayın,
ardından `site.css` ya da `app.css` içine:

```css
@import 'cms-table.css';
```

Veya doğrudan `_Host.cshtml` içine:

```html
<link rel="stylesheet" href="css/cms-table.css" />
```

### 3. Bileşenleri _Imports.razor'a ekle

`_Imports.razor` içinde bu namespace açık olmalı (proje yapınıza göre):

```razor
@using YourProject.Shared.Components.Table
```

---

## Düzeltilen Hatalar

| Sayfa | Hata | Düzeltme |
|-------|------|----------|
| Contents | Toolbar'da ve filtre şeridinde 2 arama kutusu aynı `_search` alanına bağlıydı → çift tetiklenme | Toolbar'daki kutu kaldırıldı, tek kutu filtre şeridinde kaldı |
| Contents | Edit butonunda `<SvgIcon>` + `<svg>` yan yana → 2 ikon görünüyordu | Ham `<svg>` kaldırıldı, yalnızca `<SvgIcon>` kullanılıyor |
| Roles | Arama kutusu `@bind` olmadan eklenmişti → yazılana rağmen filtreleme olmuyordu | `@bind="_search"` + `@bind:event="oninput"` eklendi |
| Roles | Silme onayı inline modal olarak tekrarlanmıştı | `<ConfirmModal>` component kullanılıyor |
| Users | Son giriş sütunundaki içerik `@* *@` yorum içindeydi → sütun boş görünüyordu | Yorum kaldırıldı |
| Users | `SaveEdit`'te `_users[i] = roleResult.Data with { = _editActive }` → derleme hatası | `await LoadAsync()` ile liste yeniden çekiliyor |

---

## DataTable Kullanım Özeti

```razor
<DataTable TItem="MyDto"
           Items="@_items"
           Loading="@_loading"
           Error="@_error"
           OnRetry="LoadAsync"
           TotalCount="@_totalCount"
           CurrentPage="@_page"
           PageSize="@_pageSize"
           OnPageChange="p => { _page = p; _ = LoadAsync(); }"
           OnPageSizeChange="s => { _pageSize = s; _page = 0; _ = LoadAsync(); }"
           SortField="@_sort"
           SortDir="@_dir"
           OnSort="SetSort"
           Selectable="true"
           SelectedIds="@_selected"
           GetId="x => x.Id"
           ExportFileName="veriler"
           ExportData="GetExportRows"
           EmptyMessage="Kayıt yok"
           EmptyColspan="5">

    <Header>
        <th>Ad</th>
        <th>Tarih</th>
    </Header>

    <RowTemplate Context="item">
        <td>@item.Name</td>
        <td>@item.Date.ToString("dd.MM.yy")</td>
    </RowTemplate>

    <RowActions Context="item">
        <button class="btn-ghost btn-icon" @onclick="() => Edit(item)">
            <SvgIcon Name="icon-edit" Size="13" />
        </button>
    </RowActions>
</DataTable>
```

### Export delegate imzası

```csharp
async Task<List<Dictionary<string, object?>>> GetExportRows(ExportButton.ExportScope scope)
{
    var src = scope == ExportButton.ExportScope.Selected
        ? _items.Where(x => _selected.Contains(x.Id))
        : (IEnumerable<MyDto>)_items;

    return src.Select(x => new Dictionary<string, object?>
    {
        ["Ad"]    = x.Name,
        ["Tarih"] = x.Date.ToString("dd.MM.yyyy"),
    }).ToList();
}
```

---

## Paginator Bağımsız Kullanım

```razor
<Paginator CurrentPage="@_page"
           TotalCount="@_total"
           PageSize="@_size"
           OnPageChange="p => { _page = p; _ = Load(); }"
           OnPageSizeChange="s => { _size = s; _page = 0; _ = Load(); }"
           PageSizeOptions="new[] { 10, 25, 50 }" />
```

---

## ExportButton Bağımsız Kullanım

```razor
<ExportButton FileName="kullanicilar"
              ExportData="GetExportRows"
              SelectedCount="@_sel.Count"
              TotalCount="@_users.Count" />
```
