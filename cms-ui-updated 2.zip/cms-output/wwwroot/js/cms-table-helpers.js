// cms-table-helpers.js
// DataTable ve ExportButton bileşenlerinin kullandığı JS interop fonksiyonları
// wwwroot/js/ altına ekleyin ve _Host.cshtml / index.html içinde referans verin.

/**
 * Metin içeriğini dosya olarak indiren yardımcı.
 * @param {string} filename  - İndirilecek dosya adı (uzantı dahil)
 * @param {string} mimeType  - MIME tipi (ör: "text/csv;charset=utf-8")
 * @param {string} content   - Dosya içeriği
 */
window.cmsDownloadText = function (filename, mimeType, content) {
    const blob = new Blob([content], { type: mimeType });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }, 100);
};

/**
 * Base64 binary içeriği dosya olarak indirir (ileride Excel export için).
 * @param {string} filename
 * @param {string} mimeType
 * @param {string} base64Content
 */
window.cmsDownloadBase64 = function (filename, mimeType, base64Content) {
    const bytes  = atob(base64Content);
    const arr    = new Uint8Array(bytes.length);
    for (let i = 0; i < bytes.length; i++) arr[i] = bytes.charCodeAt(i);
    const blob   = new Blob([arr], { type: mimeType });
    const url    = URL.createObjectURL(blob);
    const a      = document.createElement('a');
    a.href       = url;
    a.download   = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }, 100);
};
